<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../styles/main.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
<div id="footer">
            <div id="base">
                <div class="basebox">
                    <h2 style="color: rgb(230, 215, 215); text-align: center;">Visit Us</h2><hr>
                    <p style="padding: 20px;">No 10, Stanley Road,<br>Panchikawatta<br>Colombo-10</p>
                </div>

                <div class="basebox">
                    <h2 style="color: rgb(230, 215, 215); text-align: center;">Connect with Us</h2><hr>
                    <p style="text-align: left;">
                    <pre class="contact">  <i class='fa fa-envelope'></i>   info@OneDrop.lk</pre>
                    <pre class="contact">  <i class='fa fa-facebook'></i>   facebook.com/OneDrop</pre>
                    <pre class="contact">  <i class='fa fa-twitter'></i>   twitter.com/OneDrop</pre>
                    <pre class="contact">  <i class='fa fa-instagram'></i>   instagram.com/OneDrop</pre>
                    <pre class="contact">  <i class='fa fa-phone'></i>   077-2251757</pre>
                    </p>
                </div>
            </div>
            <p>&copy Copyright Reserved by OneDrop.</p> 
        </div>
</body>
</html>